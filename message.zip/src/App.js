import React, { Component } from 'react';
import MessageList from './components/messagelist';
import Header from './components/header';
import MessageBox from './components/messagebox';
import firebase from 'firebase';

class App extends Component {
  constructor(props){
    super(props);
    var config = {
      apiKey: "AIzaSyD8iRMwBq8GThDwsFIj8lTLPLL-I_uGNlU",
      authDomain: "jimss-1a05d.firebaseapp.com",
      databaseURL: "https://jimss-1a05d.firebaseio.com",
      projectId: "jimss-1a05d",
      storageBucket: "jimss-1a05d.appspot.com",
      messagingSenderId: "559550735863"
    };
    firebase.initializeApp(config);
    
  }
  render() {
    return (
      <div className="container">
      <Header title="Simple Firebase App" />
      <div className="columns">
        <div className="column is-3"></div>
        <div className="column is-6">
          <MessageList db={firebase} />
        </div>
      </div>
      <div className="columns">
        <div className="column is-3"></div>
        <div className="column is-6">
          <MessageBox db={firebase} />
        </div>
      </div>
  </div>
    );
  }
}

export default App;